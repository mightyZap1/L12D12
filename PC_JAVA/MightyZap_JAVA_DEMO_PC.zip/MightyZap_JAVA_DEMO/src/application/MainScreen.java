package application;
import java.net.URL;
import java.util.Enumeration;
import java.util.ResourceBundle;

import gnu.io.CommPortIdentifier;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import IRROBOT.Mightyzap.MightyZap;
import IRROBOT.Mightyzap.SerialTest;

public class MainScreen implements Initializable {
	static MightyZap MZap = new MightyZap();
	public static SerialTest MightyZap = new SerialTest();
	int error,Connected=0;
	@FXML
    private CheckBox ins_Error,
    				Over_Error,
    				Check_Error,
    				Range_Error,
    				Stroke_Error,
    				Volt_Error,
    				ins_ShutDown,
    				Over_ShutDown,
    				Check_ShutDown,
    				Range_ShutDown,
    				Stroke_ShutDown,
    				Volt_ShutDown;
    @FXML
    private Button Btn_GoalPosition,Btn_Connext;

    @FXML
    private ComboBox<String> Port_list,Baud_list;

    @FXML
    private TextField GoalPositionTxt,
    					ServoID_txt,
    					SStrokeLimitTxt,
    					LStrokeLimitTxt,
    					GoalSpeedTxt,
    					GoalCurrentTxt,
    					PresentPositionTxt,
    					Write_Addr,
    					Write_AddrBytes,
    					Write_Data,
    					Read_Addr,
    					Read_AddrBytes,
    					Read_Data;
    
    public void searchForPorts()
    {
		@SuppressWarnings("unchecked")
		Enumeration<CommPortIdentifier> ports = CommPortIdentifier.getPortIdentifiers();

		Port_list.getItems().clear();
        while (ports.hasMoreElements())
        {        	 
            CommPortIdentifier curPort = (CommPortIdentifier)ports.nextElement();

            if (curPort.getPortType() == CommPortIdentifier.PORT_SERIAL)
            {
            	Port_list.getItems().add(curPort.getName());
            }            
        }       
    }
    
    @FXML
    void go_searchForPorts(MouseEvent event) {
    	searchForPorts();
    }
    
    @FXML
    void Go_GoalPosition(ActionEvent event) throws Exception {
    	int ServoID = Integer.parseInt(ServoID_txt.getText());
    	int data = Integer.parseInt(GoalPositionTxt.getText());
    	MightyZap.GoalPosition(ServoID, data);    	
    	Error();
    }
    


    @FXML
    void Go_ShortStrokeLimit(ActionEvent event) throws Exception {
    	int ServoID = Integer.parseInt(ServoID_txt.getText());
    	int data = Integer.parseInt(SStrokeLimitTxt.getText());
    	MightyZap.ShortStrokeLimit(ServoID, data);
    	Error();
    }
    @FXML
    void Go_LongStrokeLimit(ActionEvent event) throws Exception {
    	int ServoID = Integer.parseInt(ServoID_txt.getText());
    	int data = Integer.parseInt(LStrokeLimitTxt.getText());
    	MightyZap.LongStrokeLimit(ServoID, data);
    	Error();
    }
    @FXML
    void Go_PresentPosition(ActionEvent event) throws Exception {
    	int ServoID = Integer.parseInt(ServoID_txt.getText());
    	 
    	 int data = MightyZap.PresentPosition(ServoID);
    	PresentPositionTxt.setText(String.valueOf(data));
    	Error();
    }
    @FXML
    void Go_Write(ActionEvent event) throws Exception {
    	int ServoID = Integer.parseInt(ServoID_txt.getText());
    	int Addr = Integer.parseInt(Write_Addr.getText());
    	int AddrBytes = Integer.parseInt(Write_AddrBytes.getText());
    	int data = Integer.parseInt(Write_Data.getText());
    	MightyZap.WriteAddr(ServoID, Addr, AddrBytes, data);
    	Error();
    }
    @FXML
    void Go_Read(ActionEvent event) throws Exception {
    	int ServoID = Integer.parseInt(ServoID_txt.getText());
    	int Addr = Integer.parseInt(Read_Addr.getText());
    	int AddrBytes = Integer.parseInt(Read_AddrBytes.getText());
    	int data = MightyZap.ReadAddr(ServoID, Addr, AddrBytes);    	    
    	Read_Data.setText(String.valueOf(data));
    	Error();
    }
    
    void Error() throws Exception {
    	int ServoID = Integer.parseInt(ServoID_txt.getText());
    	error = MightyZap.ReadError(ServoID);
        if ((error & 0x40) == 0x40) ins_Error.setSelected(true);
        else ins_Error.setSelected(false);
        if ((error & 0x20) == 0x20) Over_Error.setSelected(true);
        else Over_Error.setSelected(false);
        if ((error & 0x10) == 0x10) Check_Error.setSelected(true);
        else Check_Error.setSelected(false);
        if ((error & 0x08) == 0x08) Range_Error.setSelected(true);
        else Range_Error.setSelected(false);
        if ((error & 0x02) == 0x02) Stroke_Error.setSelected(true);
        else Stroke_Error.setSelected(false);
        if ((error & 0x01) == 0x01) Volt_Error.setSelected(true);
        else Volt_Error.setSelected(false);
    }
    
    @FXML
    void Go_ReadShutdown(ActionEvent event) throws Exception {
    	int ServoID = Integer.parseInt(ServoID_txt.getText());
    	int sdAlarm;
        sdAlarm = MightyZap.GetShutDownEnable(ServoID);

        if ((sdAlarm & 0x40) == 0x40) ins_ShutDown.setSelected(true);
        else ins_ShutDown.setSelected(false);
        if ((sdAlarm & 0x20) == 0x20) Over_ShutDown.setSelected (true);
        else Over_ShutDown.setSelected (false);
        if ((sdAlarm & 0x10) == 0x10) Check_ShutDown.setSelected(true);
        else Check_ShutDown.setSelected(false);
        if ((error & 0x08) == 0x08) Range_ShutDown.setSelected(true);
        else Range_ShutDown.setSelected(false);
        if ((sdAlarm & 0x02) == 0x02) Stroke_ShutDown.setSelected(true);
        else Stroke_ShutDown.setSelected(false);
        if ((sdAlarm & 0x01) == 0x01) Volt_ShutDown.setSelected(true);
        else Volt_ShutDown.setSelected(false);
    	
    }
    @FXML
    void Go_WriteShutdown(ActionEvent event) throws Exception {
    	 byte Alarm=0;
		 int ServoID = Integer.parseInt(ServoID_txt.getText());

         if (ins_ShutDown.isSelected() == true) Alarm |= 0x40;
         if (Over_ShutDown.isSelected() == true) Alarm |= 0x20;
         if (Check_ShutDown.isSelected() == true) Alarm |= 0x10;
         if (Range_ShutDown.isSelected() == true) Alarm |= 0x08;
         if (Stroke_ShutDown.isSelected() == true) Alarm |= 0x02;
         if (Volt_ShutDown.isSelected() == true) Alarm |= 0x01;

         MightyZap.SetShutDownEnable(ServoID,Alarm);
    }
    @FXML
    void Go_ErrorRead(ActionEvent event) throws Exception {    	
    	Error();
    }
    
    
    
    @FXML
    void Connect(ActionEvent event)  throws NumberFormatException, Exception {  	    	
    	int ServoID = Integer.parseInt(ServoID_txt.getText());
		int data;
		if(Connected==0) {
			MightyZap.OpenMightyZap(Port_list.getValue(), Integer.parseInt(Baud_list.getValue()));
			data = MightyZap.PresentPosition(ServoID);
			GoalPositionTxt.setText(String.valueOf(data));			
			PresentPositionTxt.setText(String.valueOf(data));
			data = MightyZap.ShortStrokeLimit(ServoID);
			SStrokeLimitTxt.setText(String.valueOf(data));
			data = MightyZap.LongStrokeLimit(ServoID);			
			LStrokeLimitTxt.setText(String.valueOf(data));
	
			Error();
			Btn_Connext.setText("DISCONNECT");
			Connected=1;
		}else {
			 MightyZap.CloseMightyZap();
			 Btn_Connext.setText("CONNECT");
			 Connected=0;
		}
	
    }
    

	@FXML
	void Go_Close(ActionEvent event) throws Exception {    	
		if(Connected==1) {			
			 MightyZap.CloseMightyZap();			 			 
		}
		System.exit(1);
	}
    
    
    @Override
	public void initialize(URL arg0, ResourceBundle arg1) {		
    	ServoID_txt.setText(String.valueOf(0));
		Port_list.getItems().addAll("COM1");
		Port_list.setValue("COM1");
		Baud_list.getItems().addAll("9600","19200","57600","115200");
		Baud_list.setValue("57600");
	

		
		
		searchForPorts();
	
	}
}
